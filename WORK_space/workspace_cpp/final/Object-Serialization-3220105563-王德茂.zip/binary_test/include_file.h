#ifndef INCLUDE_FILE_H
#define INCLUDE_FILE_H

#include <memory>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <list>
#include <typeinfo>
#include <cstdarg>
#include <set>
#include <map>
#include <algorithm>
#include <stdexcept>
#endif