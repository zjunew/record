#include "castle.h"

int main()
{
    //start
    castle A ;
    A.init();
    A.newstart();

    //    
    return 0;
}